import Donation from '../model/Donation.js';

export const Submit = async (req, res) => {
    const { fullName, mobileNumber, email, donationItem, handoverDate, message } = req.body;

    try {
        const donation = new Donation({ fullName , mobileNumber, email, donationItem, handoverDate, message });
        await donation.save();

        res.sendStatus(200);
    } catch (error) {
        console.error('Error submitting donation:', error);
        res.sendStatus(500);
    }
};