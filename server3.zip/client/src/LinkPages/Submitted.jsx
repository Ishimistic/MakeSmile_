// import React from 'react';

const SuccessPage = () => {
    return (
        <div>
            <h1>Form submitted successfully!</h1>
        </div>
    );
};

export default SuccessPage;